var searchData=
[
  ['isequal',['isEqual',['../class_mathematical_operations.html#a330c53fe795e1f79efbb4e81cec155d7',1,'MathematicalOperations']]],
  ['isgreater',['isGreater',['../class_mathematical_operations.html#a230b8ffcef3b6ee25f84da0beb1f5cdc',1,'MathematicalOperations']]],
  ['issmaller',['isSmaller',['../class_mathematical_operations.html#a4cda1745e446f22902c0f77e61cd75a5',1,'MathematicalOperations']]]
];
